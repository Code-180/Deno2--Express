// deno-lint-ignore-file no-explicit-any no-unused-vars prefer-const
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
import { z } from "zod";
import express from "npm:express";
import { default as mongoose } from "npm:mongoose";
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Model
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
import userSchema from "./schema/userSchema.ts";
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
let userModel = mongoose.model("users", userSchema);
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Config
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const app = express();
const port = 3000;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Middleware to parse JSON
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
app.use(express.json());
//+++++++++++++++++++++++++++++++++++++++++++++
// MongoDB Connection START
//+++++++++++++++++++++++++++++++++++++++++++++
const mongosCon: any = "mongodb://localhost:27017/youtube_deno2_express";
//+++++++++++++++++++++++++++++++++++++++++++++
mongoose.connect(mongosCon).then(() => {
    console.log("Database Connection Successfull!");
}).catch((e) => {
    console.log(e);
    console.log("Database Connection Failed!");
});
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//TEST API
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
app.get("/", (req: any, res: any) => {
    res.send("Hello World! From Deno2");
});
//+++++++++++++++++++++++++++++++++++++++++++
//Create
//+++++++++++++++++++++++++++++++++++++++++++
const userCreateValidateSchema = z.object({
    name: z.string(),
    email: z.string().email(),
    phone: z.number(),
});
app.post("/create-user", async (req: any, res: any) => {
    let resData: any = {
        status: false,
        r: {},
        message: "",
    };
    const result = userCreateValidateSchema.safeParse(req.body);
    if (!result.success) {
        resData.status = false;
        resData.message = result.error.format();
        return res.status(200).json(resData);
    } else {
        try {
            const body = req.body;
            //+++++++++++++++++++++++++++++++++++++++++
            let emailCount = await userModel.countDocuments({
                "email": body.email,
            });
            //+++++++++++++++++++++++++++++++++++++++++
            let phoneCount = await userModel.countDocuments({
                "phone": body.phone,
            });
            if (emailCount != 0) {
                resData.status = false;
                resData.message = "Try a Diffrent Email. Alreday In Use";
                return res.status(200).json(resData);
            }
            if (phoneCount != 0) {
                resData.status = false;
                resData.message = "Try a Diffrent Phone Number. Alreday In Use";
                return res.status(200).json(resData);
            }
            //+++++++++++++++++++++++++++++++++++++++++
            if (emailCount == 0 && phoneCount == 0) {
                //+++++++++++++++++++++++++++++++++++++++++
                const OBJ = await new userModel(body).save();
                //+++++++++++++++++++++++++++++++++++++++++
                resData.r = OBJ;
                //+++++++++++++++++++++++++++++++++++++++++
                resData.status = true;
                resData.message = "Created Successfully";
                return res.status(200).json(resData);
            }
        } catch (e: any) {
            //+++++++++++++++++++++++++++++++++++++++++
            //console.log(e);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = "Error!!";
            resData.data = JSON.stringify(e);
            return res.status(200).json(resData);
        }
    }
});
//+++++++++++++++++++++++++++++++++++++++++++
//Update
//+++++++++++++++++++++++++++++++++++++++++++
const userUpdateValidateSchema = z.object({
    _id: z.string(),
    name: z.string(),
    email: z.string().email(),
    phone: z.number(),
});
app.put("/update-user", async (req: any, res: any) => {
    let resData: any = {
        status: false,
        r: {},
        message: "",
    };
    const result = userUpdateValidateSchema.safeParse(req.body);
    if (!result.success) {
        resData.status = false;
        resData.message = result.error.format();
        return res.status(200).json(resData);
    } else {
        try {
            const body = req.body;
            //+++++++++++++++++++++++++++++++++++++++++
            const OBJ = await userModel.findByIdAndUpdate(
                body._id,
                body,
                {
                    returnDocument: "after",
                },
            );
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = OBJ;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Updated Successfully";
            return res.status(200).json(resData);
        } catch (e: any) {
            //+++++++++++++++++++++++++++++++++++++++++
            //console.log(e);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = "Error!!";
            resData.data = JSON.stringify(e);
            return res.status(200).json(resData);
        }
    }
});
//+++++++++++++++++++++++++++++++++++++++++++
//List All
//+++++++++++++++++++++++++++++++++++++++++++
app.get("/list-users", async (req: any, res: any) => {
    let resData: any = {
        status: false,
        r: {},
        message: "",
    };
    try {
        //+++++++++++++++++++++++++++++++++++++++++
        let pageSize = 10;
        //+++++++++++++++++++++++++++++++++++++++++
        let pageNumber = 1;
        //+++++++++++++++++++++++++++++++++++++++++
        let limit = pageSize * pageNumber;
        let offset = pageSize * (pageNumber - 1);
        //+++++++++++++++++++++++++++++++++++++++++
        resData.r = await userModel.find().sort({ createdAt: "descending" }).skip(offset).limit(pageSize);
        resData.count = await userModel.countDocuments();
        //+++++++++++++++++++++++++++++++++++++++++
        resData.status = true;
        resData.message = "List";
        return res.status(200).json(resData);
    } catch (e: any) {
        //+++++++++++++++++++++++++++++++++++++++++
        //console.log(e);
        //+++++++++++++++++++++++++++++++++++++++++
        resData.status = false;
        resData.message = "Error!!";
        resData.data = JSON.stringify(e);
        return res.status(200).json(resData);
    }
});
//+++++++++++++++++++++++++++++++++++++++++++
//Single
//+++++++++++++++++++++++++++++++++++++++++++
const userSingleValidateSchema = z.object({
    _id: z.string(),
});
app.get("/single-user", async (req: any, res: any) => {
    let resData: any = {
        status: false,
        r: {},
        message: "",
    };
    const result = userSingleValidateSchema.safeParse(req.query);
    if (!result.success) {
        resData.status = false;
        resData.message = result.error.format();
        return res.status(200).json(resData);
    } else {
        try {
            const body = req.query;
            //+++++++++++++++++++++++++++++++++++++++++
            const OBJ = await userModel.findById(
                body._id,
            );
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = OBJ;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Single";
            return res.status(200).json(resData);
        } catch (e: any) {
            //+++++++++++++++++++++++++++++++++++++++++
            //console.log(e);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = "Error!!";
            resData.data = JSON.stringify(e);
            return res.status(200).json(resData);
        }
    }
});
//+++++++++++++++++++++++++++++++++++++++++++
//Delete
//+++++++++++++++++++++++++++++++++++++++++++
const userDeleteValidateSchema = z.object({
    _id: z.string(),
});
app.delete("/destroy-user", async (req: any, res: any) => {
    let resData: any = {
        status: false,
        r: {},
        message: "",
    };
    const result = userDeleteValidateSchema.safeParse(req.query);
    if (!result.success) {
        resData.status = false;
        resData.message = result.error.format();
        return res.status(200).json(resData);
    } else {
        try {
            const body = req.query;
            //+++++++++++++++++++++++++++++++++++++++++
            const OBJ = await userModel.findByIdAndDelete(
                body._id,
            );
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = OBJ;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Deleted";
            return res.status(200).json(resData);
        } catch (e: any) {
            //+++++++++++++++++++++++++++++++++++++++++
            //console.log(e);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = "Error!!";
            resData.data = JSON.stringify(e);
            return res.status(200).json(resData);
        }
    }
});
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
app.listen(port, () => {
    console.log(`Example app listening on port ${port}`);
});
