//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Import
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
import { default as mongoose } from "npm:mongoose";
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const userSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: false
        },
        email: {
            type: String,
            required: false
        },
        phone: {
            type: String,
            required: false
        },
        password: {
            type: String,
            required: false,
            select: false,
        },
    },
    {
        timestamps: true,
    }
);
//+++++++++++++++++++++++++++++++++++++++++++++
export default userSchema;
//+++++++++++++++++++++++++++++++++++++++++++++

